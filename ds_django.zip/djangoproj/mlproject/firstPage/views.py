from django.shortcuts import render
from django.http import HttpResponse
import pandas as pd
import joblib
import os,sys
sys.path.append('.')

model_not_NA = joblib.load('./data/model/model.pkl')
model_NA = joblib.load('./data/model/modelNA.pkl')


# Create your views here.
def index(request):
	#context = {'a': 1}
	return render(request,'index.html')
	#return HttpResponse({'a' : 1})

def prediction(request):
	return render(request, 'prediction.html')

def data_cleaning(request):
	return render(request, 'data_cleaning.html')

def eda(request):
	return render(request, 'eda.html')

def uidjango(request):
	return render(request, 'UIdjango.html')
# def predictMPG(request):
#     print (request)
#     if request.method == 'POST':
#         temp={}
#         temp['city']=request.POST.get('city')
#         temp['date']=request.POST.get('date')

#     testDtaa=pd.DataFrame({'x':temp}).transpose()
#     scoreval=reloadModel.predict(testDtaa)[0]
#     context={'scoreval':scoreval,'temp':temp}
#     return render(request,'index.html',context)

def predictions(request):
	selected = ['Month', 'Longitude', 'dist_from_north', 'prev_year','prev_2year','prev_3year','city_month_mean',
            'days_rolling_mean','years_rolling_mean','is_neg_percent','city_season_mean']
	city_agg = pd.read_csv('./data/csv/city_agg.csv')
	city_month_agg = pd.read_csv('./data/csv/city_month_agg.csv')
	city_season_agg = pd.read_csv('./data/csv/city_season_agg.csv')
	ymd_agg = pd.read_csv('./data/csv/ymd_agg.csv')
	city_season_agg['combined'] = city_season_agg.City.astype(str)+"_"+city_season_agg.Season.astype(int).astype(str)
	city_month_agg['combined1'] = city_month_agg.City.astype(str)+"_"+city_month_agg.Month.astype(int).astype(str)
	#need to write code form two seperate models
	na_flag = request.POST.get('na')
	temp = {}
	temp['City'] = request.POST.get('city')
	print(temp['City'])
	temp['Date'] = pd.to_datetime(request.POST.get('date'),format='%d-%m-%Y')
	temp['Day'] =temp['Date'].day
	temp['Month'] = temp['Date'].month
	temp['Year'] =temp['Date'].year
	temp['Season'] = (temp['Month']%12 + 3)//3

	temp['prev_year'] = ymd_agg[(ymd_agg.City==temp['City'])&(ymd_agg.Month==temp['Month'])&(ymd_agg.Day==temp['Day'])&(ymd_agg.Year==(temp['Year']-1))]['AvgTemperature'].iloc[0]
	temp['prev_2year']= ymd_agg[(ymd_agg.City==temp['City'])&(ymd_agg.Month==temp['Month'])&(ymd_agg.Day==temp['Day'])&(ymd_agg.Year==(temp['Year']-2))]['AvgTemperature'].iloc[0]
	temp['prev_3year']= ymd_agg[(ymd_agg.City==temp['City'])&(ymd_agg.Month==temp['Month'])&(ymd_agg.Day==temp['Day'])&(ymd_agg.Year==(temp['Year']-3))]['AvgTemperature'].iloc[0]
	temp['combined1'] = str(temp['City'])+"_"+str(temp['Month'])
	temp['combined'] = str(temp['City'])+"_"+str(temp['Season'])
	test_data = pd.DataFrame({'x':temp}).transpose()
	test_data = test_data.merge(city_season_agg[['combined','city_season_mean']], on = 'combined')
	test_data = test_data.merge(city_month_agg[['combined1','city_month_mean']], on = 'combined1')
	test_data = test_data.merge(city_agg, on = 'City')
	test_data['Month'] = test_data['Month'].astype(int)
	test_data['prev_year'] = test_data['prev_year'].astype(float)
	test_data['prev_2year'] = test_data['prev_2year'].astype(float)
	test_data['prev_3year'] = test_data['prev_3year'].astype(float)
	actual_date = os.path.join(str(temp['Day']),str(temp['Month']),str(temp['Year']))
	print(temp['City'])
	#scoreval = model_not_NA.predict(test_data[selected])[0]
	#print(scoreval)
	# fahrenheit = model_not_NA.predict(test_data[selected])[0]
	# scoreval = ((fahrenheit - 32.00) * 0.5556)
	# print(scoreval)
	#print(test_data[selected])
	if na_flag==0:	
		fahrenheit = model_not_NA.predict(test_data[selected])[0]
		scoreval = int((fahrenheit - 32.00) * 0.5556)
		city = temp['City']
		#print(scoreval)
		context={'scoreval':scoreval,'temp':temp,'city':city,'date':actual_date}
		return render(request,'index.html',context)
	else:
		fahrenheit = model_NA.predict(test_data[selected])[0]
		scoreval = int((fahrenheit - 32.00) * 0.5556)
		city = temp['City']
		context={'scoreval':scoreval,'temp':temp,'city':city,'date':actual_date}
		return render(request,'prediction.html',context)
# d = {'City':'Calcutta','Date':'09-07-2020',"NA":0}
# predictions(d)
